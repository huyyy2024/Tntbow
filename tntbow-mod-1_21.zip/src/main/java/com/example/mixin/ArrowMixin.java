package com.example.mixin;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.vehicle.MinecartTNT;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(AbstractArrow.class)
public abstract class ArrowMixin {

	// Chạy khi mũi tên cắm vào block
	@Inject(method = "onHitBlock", at = @At("HEAD"))
	private void tntbow$onArrowHitBlock(BlockHitResult hit, CallbackInfo ci) {
		AbstractArrow arrow = (AbstractArrow) (Object) this;
		if (!(arrow.level() instanceof ServerLevel level)) return;   // chỉ chạy phía server

		// Chỉ tính mũi tên do người chơi bắn
		Entity owner = arrow.getOwner();
		if (!(owner instanceof Player player)) return;

		// 1. Phải có ray + xe mỏ TNT trong hotbar (creative thì bỏ qua)
		boolean free = player.isCreative();
		int railSlot = tntbow$findInHotbar(player, Items.RAIL);
		int cartSlot = tntbow$findInHotbar(player, Items.TNT_MINECART);
		if (!free && (railSlot < 0 || cartSlot < 0)) return;

		// 2. Vị trí đặt = ô trống sát mặt block mà mũi tên trúng
		BlockPos railPos = hit.getBlockPos().relative(hit.getDirection());
		BlockPos below = railPos.below();

		if (!level.getBlockState(railPos).canBeReplaced()) return;
		if (!level.getBlockState(below).isFaceSturdy(level, below, Direction.UP)) return;

		// 3. Đặt ray
		BlockState rail = Blocks.RAIL.defaultBlockState();
		level.setBlockAndUpdate(railPos, rail);

		// 4. Đặt xe mỏ TNT lên ray rồi châm ngòi
		MinecartTNT cart = new MinecartTNT(level, railPos.getX() + 0.5, railPos.getY() + 0.0625, railPos.getZ() + 0.5);
		cart.primeFuse();
		level.addFreshEntity(cart);

		// 5. Người chơi vung tay + âm thanh đặt block
		player.swing(InteractionHand.MAIN_HAND, true);
		level.playSound(null, railPos, rail.getSoundType().getPlaceSound(), SoundSource.BLOCKS, 1.0F, 1.0F);

		// 6. Trừ vật phẩm
		if (!free) {
			player.getInventory().getItem(railSlot).shrink(1);
			player.getInventory().getItem(cartSlot).shrink(1);
		}
	}

	/** Tìm ô hotbar (0-8) chứa item; trả -1 nếu không có. */
	private static int tntbow$findInHotbar(Player player, Item item) {
		for (int i = 0; i < 9; i++) {
			if (player.getInventory().getItem(i).is(item)) return i;
		}
		return -1;
	}
}
